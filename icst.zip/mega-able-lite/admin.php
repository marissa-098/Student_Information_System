  <?php 
  include("config/conn.php");

  if(isset($_POST['submit'])){


            // $_SESSION['id'] = $_POST['fr_studid'];
            $query ="
            SELECT * FROM users
            WHERE username = :user
            ";

            $statement = $conn_PDO->prepare($query);
            $statement->execute(
              array( 
                'user'=> $_POST['fr_Username']
              )
            );
            $count = $statement->rowCount();
            if($count > 0 ){
          

               

              $result = $statement->fetchAll();
              foreach ($result as $row) {

                  
          //check the password from form 
                $raw_password =$_POST["fr_password"];
                $hash_password = $row["password"];
                $_SESSION["admin_id"] = $row["admin_Id"];


                 if (password_verify($raw_password, $hash_password) || ($raw_password == $hash_password)){
                
                 ?>
                <script>
                     alert("Login Success!");
                     setTimeout((window.location.href="admin/index.php"),3000);
                 </script>   

                   
                 <?php

  


          // make a global variable
                $log_id = $conn->lastInsertId();
                if(!empty($log_id)){
                  $_SESSION['type'] = $row['User_type'];
                  $_SESSION['Uname'] = $row['UName'];
                  $_SESSION['UID'] = $row['UID'];
                  $_SESSION['log_ID'] = $log_id;

                  

                 

                }

          // go to home.php
                
                header('Location:admin/index.php');
                
              }
              else{
                
                  $_SESSION['alert'] = "0";
                  ?>
                 <script>
                     alert("Login Failed!");
                 </script>    

                 <?php

                 }

              }
              
            }else{
                
                  $_SESSION['alert'] = "0";
                 }

           }
          ?>


<!DOCTYPE html>
<html>
<head>
    <!--google material icon-->
        <link rel="icon" href="img/logo_trans.png" type="image/x-icon">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ICST-ADMIN</title>
  <link rel="stylesheet" type="text/css" href="css/index1.css">
<!--   <link rel="stylesheet" type="text/css" href="css/index.css">
  <link rel="stylesheet" href="css/custom.css" />
 -->
</head>

 
<body class="body" onload="myFunction()" style="margin:0;" >

  <form class="login-form" method="post">
    <h3 class="title">ADMIN LOGIN</h3>
  <p class="login-text">
    <span class="fa-stack fa-lg">
       <img src="img/logo.png">
      <!-- <i class="fa fa-circle fa-stack-2x"></i> -->
      <!-- <i class="fa fa-lock fa-stack-1x"></i> -->

    </span>
  </p>
   <?php
                  if (isset($_SESSION['alert'])) {
                    $alert = "showalert";
                    session_unset();
                  }
                  ?> 

                  <br/>

                  <div class="alert <?php echo $alert; ?>">
                    <strong>Try Again!</strong> Wrong username or password.
                  </div>
  <input type="text" class="login-username" name="fr_Username" alt="username" autofocus="true" required="true" placeholder="username" />
  <input type="text" name="fr_password" id="password" class="login-password" alt="password" required="true" placeholder="Password" />
   <div class="form-group" >
                        <label class="custom-control custom-checkbox">
                            <input class="custom-control-input" type="checkbox" id="remember" onclick="myFunction()"><span class="custom-control-label">Show Password</span>
                        </label>
                    </div>
  
  <input type="submit" name="submit" value="Login" class="login-submit" />
  <a href="#" class="login-forgot-pass">forgot password?</a>

</form>

<div class="underlay-photo"></div>
<div class="underlay-black"></div> 
  
</body>





    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <script type="text/javascript">
      // document.oncontextmenu = document.body.oncontextmenu = function() {return false;}//disable right click
    </script>
        <script>
            function myFunction() {
              var x = document.getElementById("password");
              if (x.type === "password") {
                x.type = "text";
              } else {
                x.type = "password";
              }
            }
     </script>
</html>