<?php
 include("config/conn.php");
  if(isset($_POST['login'])){
          $_SESSION['id'] = $_POST['fr_studid'];

            $sql =" SELECT 'tblgradeschool' AS studentList
                FROM tblgradeschool
                WHERE tblgradeschool.StudNum = :stud_id
                UNION ALL
                SELECT 'tblsi' AS studentList
                FROM tblsi
                WHERE tblsi.StudNum = :stud_id";

                $stmt = $conn_PDO->prepare($sql);
                            $stmt->execute(
                            array( 
                                'stud_id'=> $_POST['fr_studid']
                            )
                            );
                            $count0 = $stmt->rowCount();
                            if($count0 > 0 ){
                            $res = $stmt->fetchAll();
                            foreach ($res as $newRes) {
                                //if the stud number is from tblsi
                                if($newRes["studentList"] == "tblsi"){   

                                    $queryCollege ="
                                    SELECT * FROM tblsi t1
                                    INNER JOIN tblsiadd t2 ON t1.StudNum = t2.StudNum
                                    WHERE t1.StudNum = :stud_id
                                    ";

                                    $statement = $conn_PDO->prepare($queryCollege);
                                    $statement->execute(
                                      array( 
                                        'stud_id'=> $_POST['fr_studid']
                                      )
                                    );
                                    $count = $statement->rowCount();
                                    if($count > 0 ){
                                      $result = $statement->fetchAll();
                                      foreach ($result as $row) {

                                  $raw_password = strtoupper($_POST["fr_studPass"]);
                                  $hash_password = strtoupper($row["user_pass"]);
                                  $password = $_POST["fr_studPass"];
                                  $HASHpassword = $row["user_pass"];
                                 
                                    if (password_verify($password, $HASHpassword) || ($raw_password == $hash_password)) {
                                        
                                            function get_client_ip()
                                    {
                                        foreach (array(
                                                    'HTTP_CLIENT_IP',
                                                    'HTTP_X_FORWARDED_FOR',
                                                    'HTTP_X_FORWARDED',
                                                    'HTTP_X_CLUSTER_CLIENT_IP',
                                                    'HTTP_FORWARDED_FOR',
                                                    'HTTP_FORWARDED',
                                                    'REMOTE_ADDR') as $key) {
                                            if (array_key_exists($key, $_SERVER)) {
                                                foreach (explode(',', $_SERVER[$key]) as $ip) {
                                                    $ip = trim($ip);
                                                    if ((bool) filter_var($ip, FILTER_VALIDATE_IP,
                                                                    FILTER_FLAG_IPV4 |
                                                                    FILTER_FLAG_NO_PRIV_RANGE |
                                                                    FILTER_FLAG_NO_RES_RANGE)) {
                                                        return $ip;
                                                    }
                                                }
                                            }
                                        }
                                        
                                    }

                                    $ip = get_client_ip();
                                    $loc = file_get_contents("http://ip-api.com/json/$ip");

                                    $data = json_decode($loc);

                                    $city = $data->city;
                                    $region = $data->regionName;
                                    $country = $data->country;
                                    $zip =  $data->zip;
                                    $timezone =  $data->timezone;

                                    $location = $timezone ." " . $country  ." " .$region  ." " .$city ." " .$zip;

                                    $_SESSION["location"] = $location;

                                            // Example usage
                                        $userAgent = $_SERVER['HTTP_USER_AGENT'];
                                        $insert_active_query = "
                                            INSERT INTO logs (Id, Device, location, last_login_activity)
                                            VALUES (:user_id, :device, :location, :last_activity)";
                                        $insert_statement = $conn_PDO->prepare($insert_active_query);
                                        date_default_timezone_set('Asia/Manila');
                                        $insert_statement->execute(
                                            array(
                                                'user_id' =>  $_POST['fr_studid'],
                                                    'location' => $_SESSION["location"],
                                                    'device' => $_SERVER['HTTP_USER_AGENT'],
                                                    'last_activity' => date('Y-m-d H:i:s')
                                                    
                                            )
                                        );

                                        ?>
                                        <script>
                                            alert("Login Success!");
                                            setTimeout((window.location.href="college-students/index.php"), 1000);
                                        </script>
                                        <?php
                   
                       
                             // go to home.php
                                   
                                   header('college-students/index.php');
                                   
                                 }
                                      else{
                                        
                                          $_SESSION['alert'] = "0";
                                          ?>
                                         <script>
                                             alert("Login Failed!");
                                         </script>    
                        
                                         <?php
                        
                                         }
                        
                                      }
                                      
                                    }else{
                                     
                                    $_SESSION['alert'] = "0";
                                    }

                                }else{   //if the student number is in tblgradeschool
                                    $queryGradeschool ="
                                        SELECT * FROM tblgradeschool 
                                        WHERE StudNum = :stud_id
                                        ";


                                    $statement = $conn_PDO->prepare($queryGradeschool);
                                    $statement->execute(
                                      array( 
                                        'stud_id'=> $_POST['fr_studid']
                                      )
                                    );
                                    $count = $statement->rowCount();
                                    if($count > 0 ){
                                      $result = $statement->fetchAll();
                                      foreach ($result as $row) {  
                                          //check the password from form 
                                          $raw_password = strtoupper($_POST["fr_studPass"]);
                                          $hash_password = strtoupper($row["user_pass"]);
                                          $password = $_POST["fr_studPass"];
                                          $HASHpassword = $row["user_pass"];
                                        
                                                if (password_verify($password, $HASHpassword) || ($raw_password == $hash_password)) {
                                                            function get_client_ip()
                                                            {
                                                                foreach (array(
                                                                            'HTTP_CLIENT_IP',
                                                                            'HTTP_X_FORWARDED_FOR',
                                                                            'HTTP_X_FORWARDED',
                                                                            'HTTP_X_CLUSTER_CLIENT_IP',
                                                                            'HTTP_FORWARDED_FOR',
                                                                            'HTTP_FORWARDED',
                                                                            'REMOTE_ADDR') as $key) {
                                                                    if (array_key_exists($key, $_SERVER)) {
                                                                        foreach (explode(',', $_SERVER[$key]) as $ip) {
                                                                            $ip = trim($ip);
                                                                            if ((bool) filter_var($ip, FILTER_VALIDATE_IP,
                                                                                            FILTER_FLAG_IPV4 |
                                                                                            FILTER_FLAG_NO_PRIV_RANGE |
                                                                                            FILTER_FLAG_NO_RES_RANGE)) {
                                                                                return $ip;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                                
                                                            }


                                                    $ip = get_client_ip();
                                                    $loc = file_get_contents("http://ip-api.com/json/$ip");

                                                    $data = json_decode($loc);

                                                    $city = $data->city;
                                                    $region = $data->regionName;
                                                    $country = $data->country;
                                                    $zip =  $data->zip;
                                                    $timezone =  $data->timezone;

                                                    $location = $timezone ." " . $country  ." " .$region  ." " .$city ." " .$zip;

                                                    $_SESSION["location"] = $location;



                        
                                            // Insert an activity log
                                            $insert_active_query = "
                                            INSERT INTO logs (Id, Device, location, last_login_activity)
                                            VALUES (:user_id, :device, :location, :last_activity)";
                                            $insert_statement = $conn_PDO->prepare($insert_active_query);
                                            date_default_timezone_set('Asia/Manila');
                                            $insert_statement->execute(
                                            array(
                                                'user_id' =>  $_POST['fr_studid'],
                                                    'location' => $_SESSION["location"],
                                                    'device' => $_SERVER['HTTP_USER_AGENT'],
                                                    'last_activity' => date('Y-m-d H:i:s')
                                            )
                                        );
                        
                        
        
                                         ?>
                                        <script>
                                             alert("Login Success!");
                                             setTimeout((window.location.href="gradeschool/index.php"),1000);
                                         </script>   
                        
                                           
                                         <?php
                        
                                  // go to home.php
                                        
                                        header('Location:gradeschool/index.php');
                                        
                                      }
                                      else{
                                        
                                          $_SESSION['alert'] = "0";
                                          ?>
                                         <script>
                                             alert("Login Failed!");
                                         </script>    
                        
                                         <?php
                        
                                         }
                        
                                      }
                                      
                                    }else{
                                     
                                    $_SESSION['alert'] = "0";
                                    }
                                }

                             }
                            }
                        else{
                                  $_SESSION['alert'] = "0";
                                 }

                           }
          ?>



<!DOCTYPE html>
<html lang="en">

<head>
    <title>ICST | Student-Portal </title>
    <!-- HTML5 Shim and Respond.js IE10 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 10]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
      <!-- Meta -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <meta name="author" content="codedthemes" />
      <!-- Favicon icon -->

      <link rel="icon" href="assets/images/logo_trans.png" type="image/x-icon">
      <!-- Google font-->     
      <link href="https://fonts.googleapis.com/css?family=Roboto:400,500" rel="stylesheet">
      <!-- Required Fremwork -->
      <link rel="stylesheet" type="text/css" href="assets/css/bootstrap/css/bootstrap.min.css">
      <!-- waves.css -->
      <link rel="stylesheet" href="assets/pages/waves/css/waves.min.css" type="text/css" media="all">
      <!-- themify-icons line icon -->
      <link rel="stylesheet" type="text/css" href="assets/icon/themify-icons/themify-icons.css">
      <!-- ico font -->
      <link rel="stylesheet" type="text/css" href="assets/icon/icofont/css/icofont.css">
      <!-- Font Awesome -->
      <link rel="stylesheet" type="text/css" href="assets/icon/font-awesome/css/font-awesome.min.css">
      <!-- Style.css -->
      <link rel="stylesheet" type="text/css" href="assets/css/style.css">
  </head>

  <body themebg-pattern="theme1">
  <!-- Pre-loader start -->
  <div class="theme-loader">
      <div class="loader-track">
          <div class="preloader-wrapper">
              <div class="spinner-layer spinner-blue">
                  <div class="circle-clipper left">
                      <div class="circle"></div>
                  </div>
                  <div class="gap-patch">
                      <div class="circle"></div>
                  </div>
                  <div class="circle-clipper right">
                      <div class="circle"></div>
                  </div>
              </div>
              <div class="spinner-layer spinner-red">
                  <div class="circle-clipper left">
                      <div class="circle"></div>
                  </div>
                  <div class="gap-patch">
                      <div class="circle"></div>
                  </div>
                  <div class="circle-clipper right">
                      <div class="circle"></div>
                  </div>
              </div>
            
              <div class="spinner-layer spinner-yellow">
                  <div class="circle-clipper left">
                      <div class="circle"></div>
                  </div>
                  <div class="gap-patch">
                      <div class="circle"></div>
                  </div>
                  <div class="circle-clipper right">
                      <div class="circle"></div>
                  </div>
              </div>
            
              <div class="spinner-layer spinner-green">
                  <div class="circle-clipper left">
                      <div class="circle"></div>
                  </div>
                  <div class="gap-patch">
                      <div class="circle"></div>
                  </div>
                  <div class="circle-clipper right">
                      <div class="circle"></div>
                  </div>
              </div>
          </div>
      </div>
  </div>
  <!-- Pre-loader end -->

    <section class="login-block">
        <!-- Container-fluid starts -->
        <div style=" max-width:900px;"class="container">
            <div class="row">
                 <div class=" col-sm-12">
                     <div class="text-left">
                        <img style=" width:300px; height: 80px;" src="assets/images/icstlogo.png" alt="logo.png">
                    </div>
                 </div>
             </div>
              <div class="row">
               <div class=" col-sm-4">
                </div>
                 <!-- Hover table card start -->
                <div style="background-color: rgb(165, 243, 198, 0.9);"class="card col-sm-12">
                    <div class="text-center card-header">
                        <h3> WELCOME TO STUDENT PORTAL</h3>
                    </div>
                    <div  class="row">
                        <div class="col-md-4">
                            <br>
                            <h5 style="color: green;"class="text-center">
                            <img style=" width:150px; height: 200px;" src="assets/images/logo_trans.png" alt="logo.png">
                            <br>
                            <br>
                            INNOVATIVE COLLEGE OF SCIENCE & TECHNOLOGY
                            <br>
                            <br>
                             </h5>
                        </div>
                         <div class="col-md-3">
                           <div style="text-align: justify;"class="form-group form-primary ">
                            <br>
                               <b style="font-size: 15px;">Read Me!</b>
                               <br >
                                    To prevent unauthorized use, you shall keep your password confidential
                                    and shall not share it with any third party or use it to access third
                                    party websites or services.
                                    <br>
                                <hr>
                            </div>
                            <div style="text-align: justify;" class=" form-group form-primary">
                                 <b style="font-size: 15px;">New Here!</b>
                               <br >
                                    Please use your Student ID and Password given to you by the MIS Office.
                                    Immediately report any issues or problems encountered while using the
                                    portal.
                                    <br>
                            </div>
                        </div>
                        <!-- end of col-sm-12 -->
                         <div class=" col-sm-5">
                            <!-- Authentication card start -->
                                <form class="md-float-material form-material" method="post">
                                    <br>
                                    <div class="card">
                                        <div class="card-block">
                                            <div class=" text-center form-group form-primary">
                                                <h6 class="form-bar ">ALREADY HAVE A STUDENT ID OR SP NO.?</h6>
                                                <span>( HERE ARE SOME EXAMPLES: “20-0XXXX”, “SHS20-00XXXX”, “SP20-0XXXX”. )</span>
                                            </div>
                                            <?php
                                                if (isset($_SESSION['alert'])) {
                                                    $alert = "showalert";
                                                    session_unset();
                                                }
                                                ?> 
                                                <div style="display: none" class="form-control-danger <?php echo $alert; ?>">
                                                    <strong>Try Again!</strong> Wrong username or password.
                                                </div>
                                                <br>
                                            <div class="form-group form-primary">
                                                <input type="text" name="fr_studid" class="form-control" required autocomplete="off">
                                                <span class="form-bar"></span>
                                                <label class="float-label">Student ID Or SP No.</label>
                                            </div>
                                            <div class="form-group form-primary">
                                                <input type="password" id="password" name="fr_studPass" class="form-control" required autocomplete="off">
                                                <span class="form-bar"></span>
                                                <label class="float-label">Password</label>
                                            </div>
                                            <div class="row m-t-25 text-left">
                                                <div class="col-12">
                                                    <div class="checkbox-fade fade-in-primary d-">
                                                        <label>
                                                            <input type="checkbox" id="show">
                                                            <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                                                            <span class="text-inverse">Show Password</span>
                                                        </label>
                                                    </div>
                                                    <div class="forgot-phone text-right f-right">
                                                        <a href="forgot/forgot1.php" class="text-right f-w-600"> Forgot Password?</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row m-t-30">
                                                <div class="col-md-12">
                                                    <button name="login" id="btnSubmit" type="submit" class="btn btn-primary btn-md btn-block waves-effect waves-light text-center m-b-20">Sign in</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                                
                                <!-- end of form -->
                        </div>
                        <!-- end of col-sm-12 -->
                    </div>
                </div>
                
            </div>
            <!-- end of row -->
        </div>
        <!-- end of container-fluid -->
    </section>
    <!-- Warning Section Starts -->
    <!-- Older IE warning message -->
    <!--[if lt IE 10]>
<![endif]-->
<!-- Warning Section Ends -->
<!-- Required Jquery -->
    <script type="text/javascript" src="assets/js/jquery/jquery.min.js"></script>     <script type="text/javascript" src="assets/js/jquery-ui/jquery-ui.min.js "></script>     <script type="text/javascript" src="assets/js/popper.js/popper.min.js"></script>     <script type="text/javascript" src="assets/js/bootstrap/js/bootstrap.min.js "></script>
<!-- waves js -->
<script src="assets/pages/waves/js/waves.min.js"></script>
<!-- jquery slimscroll js -->
<script type="text/javascript" src="assets/js/jquery-slimscroll/jquery.slimscroll.js "></script>
<!-- modernizr js -->
    <script type="text/javascript" src="assets/js/SmoothScroll.js"></script>     <script src="assets/js/jquery.mCustomScrollbar.concat.min.js "></script>
<!-- i18next.min.js -->
<script type="text/javascript" src="bower_components/i18next/js/i18next.min.js"></script>
<script type="text/javascript" src="bower_components/i18next-xhr-backend/js/i18nextXHRBackend.min.js"></script>
<script type="text/javascript" src="bower_components/i18next-browser-languagedetector/js/i18nextBrowserLanguageDetector.min.js"></script>
<script type="text/javascript" src="bower_components/jquery-i18next/js/jquery-i18next.min.js"></script>
<script type="text/javascript" src="assets/js/common-pages.js"></script>
 <script>
    document.getElementById("show").addEventListener("change", function() {
        var passwordInput = document.getElementById("password");
        passwordInput.type = this.checked ? "text" : "password";
    });
</script>
</body>

</html>
