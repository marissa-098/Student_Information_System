<?php 

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "icstitde_mis";

$conn_PDO = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
session_start();
 ?>