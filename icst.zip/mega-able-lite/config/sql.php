<?php 


if(!$con = mysqli_connect("localhost","root","","icstitde_mis")){

		die("could not connect");
	}
session_start();


 ?>