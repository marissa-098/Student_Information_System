
<?php

include("../../config/conn.php");



?>

<html>
 <head>
  <title>STUDENT LIST</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>  
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

   <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="../cssAdmin/bootstrap.min.css">
        <!----css3---->
        <link rel="stylesheet" href="../cssAdmin/custom.css">
        
        <!--google fonts -->
    
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    
    
    <!--google material icon-->
      <link href="https://fonts.googleapis.com/css2?family=Material+Icons"rel="stylesheet">


  
 </head>

 <style>
  .col-sm-6{
    margin-left: 20px;
  }

  .show-details-btn{
    height: 40px;
    width: 80px;
    font-size: 13px;
    color: wheat;
    background-color: green;
    
  }
  #customer_data{
  border-top: 3px green solid;
  }
 </style>
 <body>



      <div class="wrapper" >


        <div class="body-overlay"></div>
        
         <!-------------------------sidebar------------>
		     <!-- Sidebar  -->
         <nav id="sidebar">
        <div class="sidebar-header">
                  <h3><img src="../imgAdmin/logo.png" class="img-fluid"/><span>WELCOME ADMIN</span></h3>
            </div>
            <ul class="list-unstyled components">
                    <li  class="">
                        <a href="../dashboard.php" class="dashboard"><i class="material-icons">dashboard</i>
                        <span>Dashboard</span></a>
                    </li>
                    <li  class="active">
                        <a href="../studentList/index.php" class="dashboard"><i class="material-icons">account_box</i>
                        <span>Student List</span></a>
                    </li>
                    <li  class="">
                        <a href="#" class="dashboard"><i class="material-icons">supervisor_account</i>
                        <span>Department List</span></a>
                    </li>
                    <li  class="">
                        <a href="../instructors/index.php" class="dashboard"><i class="material-icons">person</i>
                        <span>Instructor List</span></a>
                    </li>
                    <li  class="">
                        <a href="../announcements/index.php" class="dashboard"><i class="material-icons">campaign</i>
                        <span>Announcements</span></a>
                    </li>
                    <li  class="">
                        <a href="../instructors/index.php" class="dashboard"><i class="material-icons">chat</i>
                        <span>Request</span></a>
                    </li>
                    <li  class="">
                        <a href="../request/index.php" class="dashboard"><i class="material-icons">live_help</i>
                        <span>Inquiry</span></a>
                    </li>
                    <li  class="">
                        <a href="../settings/index.php" class="dashboard"><i class="material-icons">settings</i>
                        <span>Settings</span></a>
                    </li>
            </ul>
        </nav>



                <!--------page-content---------------->
        
        <div id="content">
           
           <!--top--navbar----design--------->
           
          <?php
          include("../../admin/inc/topBarNav.php");
          ?>
       
                  
             <div class="main-content">
                          <div class="scroll">
                            <?php
                              include("modalProfile.php");
                            ?>

                                  <div class="xp-breadcrumbbar text-center">
                                      <h4 class="page-title">MANAGE DEPARTMENTS</h4>  
                                        <!-- <ol class="breadcrumb text-center">
                                          <<li class="breadcrumb-item"><a href="dashboard.php">Admin</a></li>
                                          <li class="breadcrumb-item active" aria-current="page">Departments</li> 
                                        </ol>                 -->
                                  </div>

                            
                              <div class="row">


                                                      <div class="container box">
                                                      <br />
                                                      <div class="row">
                                                        <div class="col-md-4"></div>
                                                        <div class="col-md-4">
                                                        <div class="form-group" style="display:flex">
                                                          <input name="filter_all" id="filter_all" class="form-control" required>
                                                          <button type="button" name="filter" id="filter" class="btn btn-info">Search</button>
                                                        </div>
                                                        <div class="form-group">
                                                        <!--  <select name="filter_country" id="filter_country" class="form-control" required>
                                                          <option value="">Select Country</option>
                                                          <?php // echo $country; ?>
                                                          </select> -->
                                                        </div>
                                                        <div class="form-group" align="center">
                                                          
                                                        </div>
                                                        </div>
                                                        <div class="col-md-4"></div>
                                                      </div>

                                                      

                                                      <div class="table-responsive">
                                                            <table id="customer_data" class="table table-bordered table-striped">
                                                          <thead >
                                                              <tr>
                                                              <th width="5%">Student No.</th>
                                                              <th width="20%">Student's Name</th>
                                                              <th width="10%">Age</th>
                                                              <th width="25%">Address</th>
                                                              <th width="25%">Contact</th>
                                                              <th width="15%">Action</th>
                                                              </tr>
                                                            </thead>
                                      
                                                           
                                                            
                                                            </table>
                                                            <br />
                                                            <br />
                                                            <br />
                                                      </div>
                                                      </div>

                                                        



                             </div>
                            </div>
                          </div>


                          <?php
                          include("../inc/footer.php");
                          ?>

        </div>   
                 
      </div>             

                </body>
                </html>


                                                    
                                                       
     <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
   <script src="../js/popper.min.js"></script>
   <script src="..//js/bootstrap.min.js"></script>

  
                                                      
                                                      
                                                   
                    <script type="text/javascript">
                          
                          $(document).ready(function(){
                            $(".xp-menubar").on('click',function(){
                              $('#sidebar').toggleClass('active');
                            $('#content').toggleClass('active');
                            });
                            
                            $(".xp-menubar,.body-overlay").on('click',function(){
                              $('#sidebar,.body-overlay').toggleClass('show-nav');
                            });
                            
                          });
                          
                      </script>
                                                      


                            <script type="text/javascript" language="javascript" >
                            $(document).ready(function(){
                              
                              fill_datatable();
                              
                              function fill_datatable(filter_all = '')
                              {
                              var dataTable = $('#customer_data').DataTable({
                                "processing" : true,
                                "serverSide" : true,
                                "order" : [],
                                "searching" : false,
                                "ajax" : {
                                url:"fetch.php",
                                type:"POST",
                                data:{
                                  filter_all:filter_all
                                }
                                }
                              });
                              }
                              
                              $('#filter').click(function(){
                              var filter_all = $('#filter_all').val();
                              //  var filter_country = $('#filter_country').val();
                              if(filter_all != '')
                              {
                                $('#customer_data').DataTable().destroy();
                                fill_datatable(filter_all);
                              }
                              else
                              {
                                alert('Please input value');
                                $('#customer_data').DataTable().destroy();
                                fill_datatable();
                              }
                              });
                              
                              
                            });
                            
                            </script>






                            


