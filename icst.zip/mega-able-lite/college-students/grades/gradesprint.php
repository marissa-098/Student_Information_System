<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>

        /* Add your existing styles here */

            /* .modalPrint {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                z-index: 99;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.5);
            }

            .modal-contentP {
                background-color: #fff;
                margin: 5% auto;
                padding: 20px;
                border: 1px solid #888;
                width: 80%;
            }

            .close {
                color: #aaa;
                float: right;
                font-size: 28px;
                font-weight: bold;
                cursor: pointer;
            }

             */

        .student-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .student-info p {
            margin: 0;
        }

        .school-info {
            display: flex;
            text-align: center;
            margin-bottom: 20px;
        }

        .school-logo {
            max-width: 100px;
            max-height: 60px;
            margin-right: 10px; /* Adjust the margin as needed */
        }

        .school-name {
            margin: 0;
        }
        #locationP{
            margin-top: -15px;
            font-style: italic;
            
        }
        #contact{
            font-style: italic;
            margin-top: -10px;

        }
        .containerTop{
          margin-left: 150px;
        }
        #registrar{
            text-align: center;
        }

        .table-container {
            overflow-x: auto;
            max-height: 400px; /* Adjust the max height as needed */
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        @media (max-width: 600px) {
            /* Adjust styles for smaller screens */
            .student-info {
                flex-direction: column;
            }

            .student-info div {
                margin-bottom: 10px;
            }
        }
    </style>
    <title>Student Grades</title>
</head>
<body>


<div id="modalPrint" class="modalPrint">
        <div class="modal-contentP">
            <span class="close" onclick="closeModal()">&times;</span>

     
         <div class="containerTop">
            <div class="school-info">
                    <img src="../img/logo.png" alt="School Logo" class="school-logo">
                    <div class="school-name">
                        <p id="innovative" class="f-mnt-B f-mgreen f-15 f-b f-k1">INNOVATIVE COLLEGE OF SCIENCE & TECHNOLOGY</p>
                        <p id="locationP" class="f-10 f-mnt">Malitbog, Bongabong, Oriental Mindoro 5211, Philippines</p>
                        <p id="contact" class="f-10 f-mnt">Tel No. (043) 283-5521 / 283-5561</p>
                    </div>
                </div>
            </div>

            <hr>

            <div id="registrar">
            <p  class=" f-mnt-B f-black f-15 f-b f-k1">OFFICE OF THE REGISTRAR</p>
            <p  class=" f-mnt-B f-black f-15 f-b f-k1"> STUDENT GRADE REPORT <br>
Second  <br>
AY:2022-2023</p>
           

            </div>

    <div class="student-info">
        <div>
            <p><strong>Student Name:</strong> John Doe</p>
            <p><strong>Student ID:</strong> 123456</p>
        </div>
        <div>
            <p><strong>Program:</strong> Computer Science</p>
            <p><strong>Batch:</strong> 2023</p>
        </div>
    </div>
  

                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Grade</th>
                                <th>Subject</th>
                                <th>Instructor</th>
                                <th>Equivalent Grade</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Table content goes here -->
                        </tbody>
                    </table>

                    <div style=" justify-content: space-between;"  class="flex">
                        <div>
                        <p><strong>Total # of Units: </strong> Computer Science</p>
                        </div>
                        <div>
                        <p><strong>Total Credits:</strong> Computer Science</p>
                        </div>
                        <div>
                        <p><strong>Gen. Weighted Ave.: </strong> Computer Science</p>
                        </div>
                    </div>

                    <div>
                        <p>Note: This report of grades is computer generated. Any query on the accuracy of data presented shall be coursed through the corresponding Registrar’s Office. </p>
                    </div>



                        </div>

                </div>
    </div>

</body>



<script>
function openModal() {
    var modal = document.getElementById('modalPrint');
    modal.style.display = 'block';
}

function closeModal() {
    var modal = document.getElementById('modalPrint');
    modal.style.display = 'none';
}

// Close the modal if the user clicks outside the modal content
window.onclick = function(event) {
    var modal = document.getElementById('modalPrint');
    if (event.target == modal) {
        modal.style.display = 'none';
    }
};
</script>
</html>
