<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>

        /* Add your existing styles here */

            /* .modalPrint {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                z-index: 99;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.5);
            }

            .modal-contentP {
                background-color: #fff;
                margin: 5% auto;
                padding: 20px;
                border: 1px solid #888;
                width: 80%;
            }

            .close {
                color: #aaa;
                float: right;
                font-size: 28px;
                font-weight: bold;
                cursor: pointer;
            }

             */

        .student-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .student-info p {
            margin: 0;
        }

        .school-info {
            display: flex;
            text-align: center;
            margin-bottom: 20px;
        }

        .school-logo {
            max-width: 100px;
            max-height: 60px;
            margin-right: 10px; /* Adjust the margin as needed */
        }

        .school-name {
            margin: 0;
        }
        #locationP{
            margin-top: -15px;
            font-style: italic;
            
        }
        #contact{
            font-style: italic;
            margin-top: -10px;

        }
        .containerTop{
          margin-left: 150px;
        }
        #registrar{
            text-align: center;
        }

        .table-container {
            overflow-x: auto;
            max-height: 400px; /* Adjust the max height as needed */
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        @media (max-width: 600px) {
            /* Adjust styles for smaller screens */
            .student-info {
                flex-direction: column;
            }

            .student-info div {
                margin-bottom: 10px;
            }
        }
                    .hidden {
                display: none;
            }
    </style>
    <title>Student Grades</title>
</head>
<body>




</body>



<script>
function printRecords() {

                var printableContent = document.getElementById('printableContent').innerHTML;

            var printWindow = window.open('', '_blank');
            printWindow.document.write('<html><head><title>Printable Records</title>');

            // Include your external stylesheets here if any
            printWindow.document.write('<link rel="stylesheet" type="text/css" href="styles.css">');

            printWindow.document.write('</head><body>');
            printWindow.document.write(printableContent);
            printWindow.document.write('</body></html>');

            // Adding a setTimeout to ensure content is loaded before printing
            setTimeout(function() {
                printWindow.document.close();
                printWindow.print();
            }, 500);

}

function closeModal() {
    var modal = document.getElementById('modalPrint');
    modal.style.display = 'none';
}

// Close the modal if the user clicks outside the modal content
window.onclick = function(event) {
    var modal = document.getElementById('modalPrint');
    if (event.target == modal) {
        modal.style.display = 'none';
    }
};
</script>
</html>
