 <?php
$dbname = 'your_database_name';  // Replace with your actual database name

try {
    $pdo = new PDO("mysql:host=localhost;dbname=$dbname", 'your_username', 'your_password');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Retrieve table names for tblsem%
    $stmtSem = $pdo->prepare("SELECT table_name
                              FROM information_schema.tables
                              WHERE table_schema = :dbname AND table_name LIKE 'tblsem%'
                              ORDER BY CREATE_TIME DESC");
    $stmtSem->bindParam(':dbname', $dbname, PDO::PARAM_STR);
    $stmtSem->execute();
    $semTables = $stmtSem->fetchAll(PDO::FETCH_COLUMN);

    // Retrieve table names for tblsubrpt%
    $stmtSubrpt = $pdo->prepare("SELECT table_name
                                 FROM information_schema.tables
                                 WHERE table_schema = :dbname AND table_name LIKE 'tblsubrpt%'
                                 ORDER BY CREATE_TIME DESC");
    $stmtSubrpt->bindParam(':dbname', $dbname, PDO::PARAM_STR);
    $stmtSubrpt->execute();
    $subrptTables = $stmtSubrpt->fetchAll(PDO::FETCH_COLUMN);

    // Combine table names for both categories
    $allTables = array_merge($semTables, $subrptTables);

    // Build the dynamic UNION queries
    $unionSemQuery = "SELECT * FROM (";
    foreach ($semTables as $index => $tableName) {
        $unionSemQuery .= "SELECT * FROM $tableName WHERE `studnum` = '20-09363'";
        if ($index < count($semTables) - 1) {
            $unionSemQuery .= " UNION ";
        }
    }
    $unionSemQuery .= ") AS semCombinedTables";

    $unionSubrptQuery = "SELECT * FROM (";
    foreach ($subrptTables as $index => $tableName) {
        $unionSubrptQuery .= "SELECT * FROM $tableName WHERE `studnum` = '20-09363'";
        if ($index < count($subrptTables) - 1) {
            $unionSubrptQuery .= " UNION ";
        }
    }
    $unionSubrptQuery .= ") AS subrptCombinedTables";

    // Build the dynamic JOIN query
    $joinQuery = "SELECT * FROM $unionSemQuery AS semResult
                  JOIN $unionSubrptQuery AS subrptResult ON semResult.common_column = subrptResult.common_column";

    // Now, you can execute $joinQuery to get the result
    $result = $pdo->query($joinQuery);

   if (count($result) > 0) {

       
        echo "<div class='table-title'>Prospectus</div>";
        echo "<div class='table-responsive'>";
        echo "<table  class='table table-bordered table-striped' border='3'>";
        echo " <tr>
                           <th width ='5%'>ID</th>
                              <th width ='7%' >Code</th>
                              <th width ='30%'>Subject Description</th>
                              <th width ='5%'>Units</th>
                              <th width ='3%'>Grade</th>
                              <th width ='3%'>Equivalent</th>
                              <th width ='3%'>Re-exam</th>
                              <th width ='5%'>Credits</th>
                              <th width ='7%'>Remarks</th>
                              <th width ='15%'>Instructor</th>
                            <tr>";

        foreach ($result as $row) {
            echo "<tr>";
            echo "<td>" . $row['id'] . "</td>";
            echo "<td>" . $row['Code'] . "</td>";
            echo "<td>" . $row['Description'] . "</td>";
            echo "<td>" . $row['Unit'] . "</td>";
            echo "<td>" . $row['finalgrade'] . "</td>";
            echo "<td>" . $row['equivalent'] . "</td>";
            echo "<td>" . $row['reexam'] . "</td>";
            echo "<td>" . $row['credit'] . "</td>";
            echo "<td>" . $row['remarks'] . "</td>";
            echo "<td>" . $row['Instructor'] . "</td>";
            echo "</tr>";
        }

        echo "</table>";
    }



} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

// Close the database connection
$pdo = null;
?>

