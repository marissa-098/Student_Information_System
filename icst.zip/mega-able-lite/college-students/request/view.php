

<style>


.close-btn {
float: right;
margin-left: 15px;
color: black;
font-weight: bold;
float: right;
font-size: 22px;
line-height: 20px;
cursor: pointer;
transition: 0.3s;
}

.close-btn:hover {
color: black;
}

.message-popup .date {
position: absolute;
bottom: 15px;
right: 15px;
color: #666;
}

.message-popup {  
width: 100%;
height: 100%;
background-color: rgba(0, 0, 0, 0.5);
align-items: center;
justify-content: center;
}

.popup-content {
height: 50%;
background-color: white;
padding: 20px;
border-radius: 5px;
position: relative;
}
.name-label {
float: left;
font-weight: bold;
width: 150px; /* Set a width for the label */
clear: left; /* Clear the float after each label-value pair */
}

.name-value {
margin-left: 10px; /* Adjust the margin as needed */
overflow: hidden; /* Prevent content from overflowing */
}
.content{
margin-bottom: 50px;
}

.update {
background-color: #6AB8E8; /* Background color */
color: #fff; /* Text color */
padding: 10px 20px; /* Padding around text */
font-size: 16px; /* Font size */
border: none; /* Remove border */
border-radius: 5px; /* Add rounded corners */
cursor: pointer; /* Add cursor pointer on hover */
transition: background-color 0.3s ease; /* Smooth transition on hover */
width: 200px;
float: right;
margin-top: 10px;
}

.update:hover {
background-color:#54CA24; /* Change background color on hover */
}



/* Responsive styles */
@media screen and (max-width: 768px) {
    .popup-content {
        padding: 10px; /* Adjust padding for smaller screens */
    }

    .name-label {
        width: 100%; /* Full width for smaller screens */
        float: none; /* Remove float on smaller screens */
        clear: both; /* Clear both on smaller screens */
        margin-bottom: 5px; /* Add some space between label-value pairs */
    }

    .name-value {
        margin-left: 0; /* Reset margin for name-value on smaller screens */
    }
}


</style>
  <link rel="stylesheet" href="css/homepagecss.css" />
 <link rel="stylesheet" href="../css/custom.css">  

 <br>
 <br> 
<div class="dashboard-wrapper">
            <div class="container-fluid  dashboard-content">
                <!-- ============================================================== -->
                <!-- pageheader -->
                <!-- ============================================================== -->
              
                <!-- ============================================================== -->
                <!-- end pageheader -->
                <!-- ============================================================== -->
               
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">Inquiry Information   <a href="./index.php?page=request" class="close-btn" onclick="closeMessage()">&times;</a> </h5>
                                <div class="card-body">
                                
                                        <?php

                                     $pn=$_GET['PN'];
                                     $req = $conn_PDO->prepare("SELECT * FROM reqchange WHERE PN = :pn");
                                     $req->bindParam(':pn', $pn, PDO::PARAM_STR);
                                     $req->execute();
                                     if($req->rowCount() > 0){
                                     while($fetch_req = $req->fetch(PDO::FETCH_ASSOC)){ 
                                           $responsedate = new DateTime($fetch_req['responseDate']);
                                           $date = new DateTime($fetch_req['date']);

                                        ?>

                        <div class="message-popup" id="messagePopup">
                            <div class="popup-content">
                                <div class="sender-info">
                                    <h3 class="sender-name">[<?= $fetch_req['StudNum']; ?>] </h3>
                                    <span class="date1"><i><?= $date->format('F d, Y g:ia'); ?></i></span>
                                </div>
                                <!-- Add data-index attribute to uniquely identify each message -->
                                 <div class="">
                                        <div class="name-label">Name:</div>
                                        <div class="name-value"><?= $fetch_req['Lname']; ?>,
                                        <?= $fetch_req['Fname']; ?> <?= $fetch_req['Mname']; ?></div>

                                        <div class="name-label">Course:</div>
                                        <div class="name-value"><?= $fetch_req['Course']; ?></div>

                                        <div class="name-label">Major:</div>
                                        <div class="name-value"><?= $fetch_req['Major']; ?></div>

                                        <div class="name-label">Gender</div>
                                        <div class="name-value"><?= $fetch_req['Sex']; ?></div>

                                        <div class="name-label">Address:</div>
                                        <div class="name-value"><?= $fetch_req['Sitio']; ?> <?= $fetch_req['Brgy']; ?> <?= $fetch_req['Town']; ?> <?= $fetch_req['Province']; ?></div>

                                        <div class="name-label">Birth Place:</div>
                                        <div class="name-value"><?= $fetch_req['BPlace']; ?></div>

                                        <div class="name-label">Contact Number:</div>
                                        <div class="name-value"><?= $fetch_req['CNumber']; ?></div>

                                        <div class="name-label">Religion:</div>
                                        <div class="name-value"><?= $fetch_req['Religion']; ?></div>

                                        <div class="name-label">Nationality:</div>
                                        <div class="name-value"><?= $fetch_req['Nationality']; ?></div>

                                        <div class="name-label">Father's Name:</div>
                                        <div class="name-value"><?= $fetch_req['Father']; ?>, <?= $fetch_req['FatherFName']; ?> <?= $fetch_req['FatherMName']; ?></div>

                                         <div class="name-label">Mother's Name:</div>
                                        <div class="name-value"><?= $fetch_req['Mother']; ?>, <?= $fetch_req['MotherFname']; ?> <?= $fetch_req['MotherMname']; ?></div>

                                        <br><br>

                                    </div>
                                    <hr>
                                    <div class="">
                                        
                                        <div class="name-label">ICST:</div>
                                        <div class="name-value"><?= $fetch_req['response']; ?>
                                            <span class="date"><i><?= $responsedate->format('F d, Y g:ia'); ?></i></span>
                                        </div>


                                        <br><br>

                                    </div>



                            </div>
                        </div>

                                        <?php 
                                            }
                                          }
                                          ?>


                                 
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end responsive table -->
                        <!-- ============================================================== -->
                    </div>
               
            </div>
            
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- end main wrapper -->
    <!-- ============================================================== -->
 
    <script type="text/javascript">
        $(document).ready(function(){
          var firstName = $('#firstName').text();
          var lastName = $('#lastName').text();
          var intials = $('#firstName').text().charAt(0) + $('#lastName').text().charAt(0);
          var profileImage = $('#profileImage').text(intials);
        });
    </script>

