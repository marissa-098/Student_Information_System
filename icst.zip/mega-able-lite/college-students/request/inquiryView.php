

<style>
.alert {
display: none;
padding: 20px;
background-color: #lime; /* Green background color for success */
color: black; /* White text color */
border-radius: 5px; /* Rounded corners */
margin-bottom: 15px;
}

.alert-danger {
background-color: #f44336; /* Red background color for danger */
}

.close-btn {
float: right;
margin-left: 15px;
color: black;
font-weight: bold;
float: right;
font-size: 22px;
line-height: 20px;
cursor: pointer;
transition: 0.3s;
}

.close-btn:hover {
color: black;
}

.message-popup .date {
    font-size: 12px;
position: absolute;
bottom: 15px;
right: 15px;
color: #666;
}.message-content{
    margin-bottom: 50px;
}

.message-popup {  
width: 100%;
height: 100%;
background-color: rgba(0, 0, 0, 0.5);
align-items: center;
justify-content: center;
}

.popup-content {
height: 50%;
background-color: white;
padding: 20px;
border-radius: 5px;
position: relative;
}
.update {
background-color: #6AB8E8; /* Background color */
color: #fff; /* Text color */
padding: 10px 20px; /* Padding around text */
font-size: 16px; /* Font size */
border: none; /* Remove border */
border-radius: 5px; /* Add rounded corners */
cursor: pointer; /* Add cursor pointer on hover */
transition: background-color 0.3s ease; /* Smooth transition on hover */
width: 200px;
float: right;
margin-top: 10px;
}

.update:hover {
background-color:#54CA24; /* Change background color on hover */
}
.date1{
    float: right;
    font-size: 12px;
}
</style>
  <link rel="stylesheet" href="css/homepagecss.css" />
 <link rel="stylesheet" href="../css/custom.css">  

<br>
<br>
<div class="dashboard-wrapper">
            <div class="container-fluid  dashboard-content">
               
                <!-- ============================================================== -->
                <!-- end pageheader -->
                <!-- ============================================================== -->
               
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">Inquiry Information   <a href="./index.php?page=request" class="close-btn" onclick="closeMessage()">&times;</a> </h5>
                                <div class="card-body">
                                
                                        <?php

                                             $pn=$_GET['PN'];
                                             $req = $conn_PDO->prepare("SELECT * FROM inquiry2324 WHERE PN = :pn");
                                             $req->bindParam(':pn', $pn, PDO::PARAM_STR);
                                                  $req->execute();
                                                  if($req->rowCount() > 0){
                                                  while($fetch_req = $req->fetch(PDO::FETCH_ASSOC)){
                                                     $fromDateTime = new DateTime($fetch_req['date']);
                                                     $responsedate = new DateTime($fetch_req['responseDate']);
                                                  
                                                         

                                        ?>




                                        <div class="message-popup" id="messagePopup">
                                        <div class="popup-content">
                                          
                                            <div class="sender-info">
                                                <h3 class="sender-name"><strong>[<?= $fetch_req['Id']; ?>] </strong></h3>
                                               
                                            </div>
                                            
                                            <strong>FROM: </strong><?= $fetch_req['LName']; ?>,<?= $fetch_req['FName']; ?> <?= $fetch_req['MName']; ?>
                                            <!-- Add data-index attribute to uniquely identify each message -->
                                            <div class="message-content">
                                                 <strong>INQUIRY TYPE: </strong><?= $fetch_req['inquiryType'];?> 
                                                 <hr>
                                                 <strong>MESSAGE: </strong><?= $fetch_req['message'];?>  
                                                 <br>
                                                 <br>
                                                 <span class="date1"><i><?= $fromDateTime->format('F d, Y g:ia'); ?></i></span>
                                            </div>
                                            <hr>

                                              <div class="">
                                                 <strong>ICST: </strong><?= $fetch_req['response'];?> 
                                                 <br>
                                                 <br>
                                                 <span class="date"><i><?= $responsedate->format('F d, Y g:ia'); ?></i></span>
                                            </div>
                                             
                                          </div>
                                         </div>
                                             <?php
                                            }
                                        }

                                                ?>


                                 
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end responsive table -->
                        <!-- ============================================================== -->
                    </div>
               
            </div>
            
        </div>
    </div>
  
    <script type="text/javascript">
        $(document).ready(function(){
          var firstName = $('#firstName').text();
          var lastName = $('#lastName').text();
          var intials = $('#firstName').text().charAt(0) + $('#lastName').text().charAt(0);
          var profileImage = $('#profileImage').text(intials);
        });
    </script>

