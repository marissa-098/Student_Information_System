   <!-- Modal 1 -->
                    <div ID="modal1" class="modal">
                        <div class="modal-content">
                        <span class="close-btn" onclick="closeModal('modal1')">&times;</span>
                       <style>
                        .containerBOX {
                            max-width: 600px; /* Adjust the maximum width as needed */
                            margin: 0 auto; /* Center the container */
                            padding: 20px;
                            text-align: center;
                        }

                        label {
                            display: block;
                            font-size: 18px;
                            margin-bottom: 10px;
                        }

                        .btn-container {
                            display: flex;
                            justify-content: space-around;
                        }

                        .button1, .button2  {
                            padding: 10px 20px;
                            font-size: 16px;
                            border: none;
                            border-radius: 5px;
                            cursor: pointer;
                            border: 2px solid #54CA24;
                        }
                        .button1{
                            background-color: #6AB8E8;
                        }
                        .button2{
                            background-color: #22B98E;
                            text-decoration: none;
                            color: white;
                        }
                         .button2:hover{
                            background-color: #54CA24;
                            text-decoration: none;
                            color: white;
                           
                        }
                         .close-btn {
                            cursor: pointer;
                            position: absolute;
                            top: 10px;
                            right: 10px;
                        }

                        /* Media query for responsiveness */
                        @media only screen and (max-width: 768px) {
                            .modal-content{
                                width: 90%;
                                margin-top:auto;
                                margin-bottom:auto;
                            }
                            .container {
                                padding: 10px;
                            }

                            .button1 {
                                font-size: 14px;
                                 margin-bottom: 10px;
                            }
                            .button2 {
                                font-size: 14px;
                                 margin-bottom: 10px;
                            }
                            .btn-container {
                            display: block;

                             }
                        }

                              
                       </style>
                                        <div class="containerBOX">
                                            <label for="exampleLabel">Do you have any concern about your information? <br>feel free to message us.</label>
                                            <div class="btn-container">
                                                <button class="button1" onclick="openModal('modalInquiry')" id="first">Submit Inquiries</button>
                                                <a href="./index.php?page=request" ><button class="button2"  id="second" class="both">View Inquiries</button></a>
                                            </div>

                                             <div id="modalInquiry" class="modal-container"></div>
                                             <div id="modalViewInquiry" class="modal-container"></div>
                                        </div>

                            <?php
                            include("../inc/inquiry.php");
                            include("../inc/viewInquiries.php");

                           
                            ?>

                           
                        </div>


     </div>