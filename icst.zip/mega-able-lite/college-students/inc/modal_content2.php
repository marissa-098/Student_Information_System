

   <!-- Modal 2 -->
                    <div id="modal2" class="modal">
                    <style>

                              .step-container {
                                  max-width: 600px;
                                  margin: auto;
                                  border: 1px solid #ddd;
                                  padding: 20px;
                                  border-radius: 5px;
                              }

                              .step {
                                  display: none;
                              }
                              .step p {
                                  font-size: 15px;
                                 text-align: justify;
                              }

                              .step.active {
                                  display: block;
                              }

                              .button2 {
                                  background-color: #4CAF50;
                                  color: white;
                                  padding: 5px 10px;
                                  border: none;
                                  font-size: 20px;
                                  border-radius: 5px;
                                  cursor: pointer;
                              }
                              .name{
                                font-style: !important;
                                color: green;
                              }

                              .button2:hover {
                                  background-color: #45a049;
                              }
                          </style>
                        <div class="modal-content">
                        <span class="close-btn" onclick="closeModal('modal2')">&times;</span>
                        
                        <div class="step-container">
                            <div class="step active" id="step1">

                        <?php
                        include "../../config/conn.php";

                          $st_id =$_SESSION['id'];
                          $select_stud = $conn_PDO->prepare (" 
                          SELECT * FROM tblsi t1
                          INNER JOIN tblsiadd t2 ON t1.StudNum = t2.StudNum
                          WHERE t1.StudNum = '$st_id'");
                          $select_stud->execute();
                          if($select_stud->rowCount() > 0){
                          while($fetch_stud = $select_stud->fetch(PDO::FETCH_ASSOC)){

                          
                            ?>
                                <h2>Welcome Student, <span class="name"><?= strtoupper($fetch_stud['Lname']); ?>,
                                                             <?= strtoupper($fetch_stud['Fname']); ?> <?= strtoupper($fetch_stud['Mname']); ?> </span></h2>

                            <?php
                            }}
                            ?>
                                <p>DISCLAIMER FOR ICST If you require any more information or have any questions about our site's disclaimer, please feel free to contact us by email at DISCLAIMERS FOR ICST.EDU.PH</p>
                                <button class="button2" onclick="nextStep()">Next</button>
                            </div>

                            <div class="step" id="step2">
                                <p>All the information on this website - http://student-portal.icst.edu.ph - is published in good faith and for general information purpose only. ICST does not make any warranties about the completeness, reliability and accuracy of this information. Any action you take upon the information you find on this website (student-portal.icst.edu.ph), is strictly at your own risk. ICST will not be liable for any losses and/or damages in connection with the use of our website.</p>
                                <button class="button2" onclick="prevStep()">Previous</button>
                                <button class="button2" onclick="nextStep()">Next</button>
                            </div>

                            <div class="step" id="step3">
                                <p>From our website, you can visit other websites by following hyperlinks to such external sites. While we strive to provide only quality links to useful and ethical websites, we have no control over the content and nature of these sites. These links to other websites do not imply a recommendation for all the content found on these sites. Site owners and content may change without notice and may occur before we have the opportunity to remove a link which may have gone 'bad'.
</p>
                                <button class="button2" onclick="prevStep()">Previous</button>
                                <button class="button2" onclick="nextStep()">Next</button>
                            </div>

                            <div class="step" id="step4">
                                <p>Please be also aware that when you leave our website, other sites may have different privacy policies and terms which are beyond our control. Please be sure to check the Privacy Policies of these sites as well as their "Terms of Service" before engaging in any business or uploading any information.
</p>
                                <button class="button2" onclick="prevStep()">Previous</button>
                                <button class="button2" onclick="finish()">Finish</button>
                            </div>
                        </div>

                        </div>
                    </div>