                  
<!-- MODAL 3 -->

<div id="modal3" class="modal">
  <div class="modal-content">
 <span class="close-btn" onclick="closeModal('modal3')">&times;</span>

 <style type="text/css">
     header {
            background-color: #f0f0f0;
            padding: 10px;
            text-align: center;
        }

        .message-list {
            flex-grow: 1;
            height: 400px;
            overflow-y: auto;
        }

        .messages {
            display: flex;
            flex-direction: column;
            padding: 10px;

        }

        .unread-messages,
        .read-messages {
            display: flex;
            flex-direction: column;
        }

        .notif {
            border: 1px solid #ccc;
            margin: 5px;
            padding: 10px;
            cursor: pointer;
            transition: background-color 0.3s;
            position: relative;
            font-size: 15px;
        }

        .notif:hover {
            background-color: #DDF1D3;
        }
       

        .read {
            background-color: #f0f0f0;
        }

        .notif .date {
            position: absolute;
            top: 5px;
            right: 5px;
            color: #666;
            font-size: 15px;
        }

        .message-popup {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            align-items: center;
            justify-content: center;
        }

        .popup-content {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            position: relative;
        }

        .close-btn {
            cursor: pointer;
            position: absolute;
            top: 10px;
            right: 10px;
        }
 </style>

       <h5>Notifications</h5>
    <div class="message-list">
        <h5>Unread Messages</h5>
        <!-- Unread Messages -->
        <div class="messages" id="UNreadContainer">
           <?php
          include("../../config/conn.php");

          $currentUserStudID = $_SESSION['id'];

          $req = $conn_PDO->prepare("SELECT * FROM reqchange");
          $req->execute();

          if ($req->rowCount() > 0) {
            while ($fetch_req = $req->fetch(PDO::FETCH_ASSOC)) {
              if ($fetch_req['StudNum'] == $currentUserStudID) {
          ?>
                <div class="notif" data-index="<?= $fetch_req['date']; ?>" onclick="openMessage(this)">
                  <div class="sender-info">
                    <span class="sender-name"><b>From: ICST</b></span>
                    <span class="date"><?= $fetch_req['date']; ?></span>
                  </div>
                  <div class="message-content">
                    <p>We received your request to change data. Please wait until we verify your information. Thank you!</p>
                  </div>
                </div>
          <?php
              }
            }
          }
          ?>
        </div>
        <hr><strong><hr></strong>
        <!-- Read Messages -->
        <div class="messages" id="ReadContainer">
            <h5>Read Messages</h5>
            <!-- Read messages will be added here -->
        </div>
    </div>

    <div class="message-popup" id="messagePopup">
        <div class="popup-content">
            <span class="close-btn" onclick="closeMessage()">&times;</span>
            <div class="sender-info">
                <span class="sender-name" id="popupSenderName"></span>
                <span class="message-date" id="popupMessageDate"></span>
            </div>
            <div class="message-content" id="popupMessageContent"></div>
        </div>
    </div>
  </div>
</div>
