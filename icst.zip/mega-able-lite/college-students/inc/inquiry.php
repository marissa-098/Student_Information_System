 <!-- Modal 1 -->
 <div id="modalInquiry" class="modal">
                        <div class="modal-content">
                        <span class="close-btn" onclick="closeModal('modalInquiry')">&times;</span>
<style>
<style>
/* Styling for the custom alert */
.alert {
display: none;
position: fixed;
top: 50%;
left: 50%;
transform: translate(-50%, -50%);
padding: 20px;
background-color: #f0f0f0;
border: 1px solid #ccc;
box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
z-index: 1000;
}

/* Fade-in animation */
@keyframes fadeIn {
from {
opacity: 0;
}
to {
opacity: 1;
}
}

/* Apply the fade-in animation to the custom alert */
.fade-in {
animation: fadeIn 0.5s ease-in-out;
}

#inquiryForm{
width: 100%;
margin:auto;
font-size: 15px;
}
form {
background-color: #fff;
border-radius: 8px;
padding: 20px;
box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
max-width: 400px;
width: 100%;
animation: fadeInUp 0.6s ease-out;
}

label {
display: block;
margin-bottom: 8px;
}

select,
textarea {
width: 100%;
padding: 10px;
margin-bottom: 16px;
border: 1px solid #ccc;
border-radius: 4px;
box-sizing: border-box;
}

button {
background-color: #4caf50;
color: #fff;
padding: 10px 15px;
border: none;
border-radius: 4px;
cursor: pointer;
font-size: 16px;
}

button:hover {
background-color: #45a049;
}

@keyframes fadeInUp {
from {
opacity: 0;
transform: translateY(20px);
}
to {
opacity: 1;
transform: translateY(0);
}
}
    

</style>
<div id="styledAlertContainer"></div>

                                    <form id="inquiryForm" action="" method="post" onsubmit="return validateForm()">
                                       
                                        <label for="inquiry-type">Nature of Inquiry:</label>
                                        <select id="inquiry-type" name="inquiry-type" required>
                                            <option value="Enrollment and Admission">Enrollment and Admission</option>
                                            <option value="Academic Records">Academic Records</option>
                                            <option value="Personal Information">Personal Information</option>
                                            <option value="Financial Information">Financial Information</option>
                                            <option value="Disciplinary Records">Disciplinary Records</option>
                                            <option value="Health and Medical Records">Health and Medical Records</option>
                                            <option value="Events and Extracurricular Activities">Events and Extracurricular Activities</option>
                                            <option value="Graduation and Alumni Services">Graduation and Alumni Services</option>
                                            <option value="Other">Other</option>
                                        </select>

                                        <label for="message">Message:</label>
                                       <textarea id="messages" name="message" rows="4" required></textarea>

                                        <button class="btnSubmit" onclick="submitForm()" type="submit">Submit Inquiry</button>
                                    </form>

                        
                        </div>
                    </div>



