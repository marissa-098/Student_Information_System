 <!-- Modal 1 -->
 <div id="modalViewInquiry" class="modal">
    <div class="modal-content">
     <span class="close-btn" onclick="closeModal('modalViewInquiry')">&times;</span>
   
   <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .inquiry-container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            width: 100%;
            max-width: 750px;
        }

        .inquiry-header {
            background-color: #4CAF50;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        .inquiry-item {
            border-bottom: 1px solid #ddd;
            padding: 20px;
            transition: background-color 0.3s;
        }

        .inquiry-item:hover {
            background-color: #f0f0f0;
        }

        .inquiry-type {
            font-weight: bold;
            color: black;
        }

        .inquiry-date {
            color: #777;
            font-size: 1em;
        }

        .empty-message {
            text-align: center;
            padding: 20px;
            color: #777;
        }
        table{
             width: 100%;
        }
        .head th{
             background-color: #618264;
             color: black;
        }

        table,
        th,
        td {
            border: 1px solid black;
            border-collapse: collapse;
            padding: 5px;
            font-size: 12px;
           
        }
 
        tr:nth-child(odd) {
            background-color: #F2f3f4;
        }
    </style>
                                

                              
                       </style>

                       <div class="inquiry-container">
                                    <div class="inquiry-header">
                                        <h2>Inquiries Dashboard</h2>
                                    </div>
                                    <table>
                                    <tr class="head">
                                                <th width="35%">Type</th>
                                                <th width="50%">Message</th>
                                                <th width="25%">Date</th>
                                                <th width="25%">Status</th>
                                            </tr>

                                   

                                    

                                    <?php
                                    include "../../config/conn.php";
                                        // Assuming $inquiries is an array of inquiry data fetched from the database
                                            if(isset($_SESSION["id"])){
                                                $ID = $_SESSION["id"];

                                                $sqlInquiry = $conn_PDO->prepare (" 
                                                SELECT * FROM inquiry2324
                                                WHERE Id = '$ID'");
                                                $sqlInquiry->execute();
                                                if($sqlInquiry->rowCount() > 0){
                                                while($fetch_inquiry = $sqlInquiry->fetch(PDO::FETCH_ASSOC)){


                                                ?>
                                               
                                             <tr>
                                                <td class="inquiry-type">  <?= $fetch_inquiry['inquiryType']; ?></td>
                                               <td> <?= $fetch_inquiry['message']; ?></td>
                                               <td class="inquiry-date">Submitted on  <?= $fetch_inquiry['date']; ?></td>
                                               <td class="inquiry-date"><?php 
                                                       if($fetch_inquiry['status'] ==="Pending"){
                                                           echo '<span class="badge bg-info text-white">Pending</span>';
                                                         } else if($fetch_inquiry['status'] ==="read"){
                                                           echo '<span class="badge bg-success text-white">Receive</span>';
                                                        }
                                                     ?> </td>
                                            </tr>
                                               
                                               
                                           

                                            <?php
                                            }
                                        } else {
                                            echo '<div class="empty-message">No inquiries found.</div>';
                                        }
                                    }
                                    ?>

                               </table>
                                </div>
             
                        </div>
                    </div>
