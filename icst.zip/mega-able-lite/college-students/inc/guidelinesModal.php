 <!-- Modal 2 -->
                    <div id="modal2" class="modal">
                    <style>

                              .step-container {
                                  max-width: 600px;
                                  margin: auto;
                                  border: 1px solid #ddd;
                                  padding: 20px;
                                  border-radius: 5px;
                              }

                              .step {
                                  display: none;
                              }

                              .step.active {
                                  display: block;
                              }

                              .button2 {
                                  background-color: #4CAF50;
                                  color: white;
                                  padding: 10px 15px;
                                  border: none;
                                  border-radius: 5px;
                                  cursor: pointer;
                              }

                              .button2:hover {
                                  background-color: #45a049;
                              }
                          </style>
                        <div class="modal-content">
                        <span class="close-btn" onclick="closeModal('modal2')">&times;</span>
                        
                        <div class="step-container">
                            <div class="step active" id="step1">
                                <h2>Step 1: Welcome to Our School</h2>
                                <p>This is the first step of our guidelines. Please read carefully.</p>
                                <button class="button2" onclick="nextStep()">Next</button>
                            </div>

                            <div class="step" id="step2">
                                <h2>Step 2: Academic Policies</h2>
                                <p>Here are the academic policies you need to be aware of.</p>
                                <button class="button2" onclick="prevStep()">Previous</button>
                                <button class="button2" onclick="nextStep()">Next</button>
                            </div>

                            <div class="step" id="step3">
                                <h2>Step 3: Code of Conduct</h2>
                                <p>Review and adhere to our school's code of conduct.</p>
                                <button class="button2" onclick="prevStep()">Previous</button>
                                <button class="button2" onclick="nextStep()">Next</button>
                            </div>

                            <div class="step" id="step4">
                                <h2>Step 4: Campus Facilities</h2>
                                <p>Explore our campus facilities and their proper usage.</p>
                                <button class="button2" onclick="prevStep()">Previous</button>
                                <button class="button2" onclick="finish()">Finish</button>
                            </div>
                        </div>

                        <script>
                            var currentStep = 1;

                            function showStep(stepNumber) {
                                var steps = document.querySelectorAll('.step');
                                steps.forEach(function(step) {
                                    step.classList.remove('active');
                                });

                                document.getElementById('step' + stepNumber).classList.add('active');
                            }

                            function nextStep() {
                                if (currentStep < 4) {
                                    currentStep++;
                                    showStep(currentStep);
                                }
                            }

                            function prevStep() {
                                if (currentStep > 1) {
                                    currentStep--;
                                    showStep(currentStep);
                                }
                            }

                            function finish() {
                                alert('Thank you for reviewing our school guidelines!');
                                // You can redirect the user or perform other actions after finishing the guidelines.
                            }
                        </script>


                        </div>
                    </div>