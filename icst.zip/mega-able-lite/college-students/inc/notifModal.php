 <!-- Modal 3 -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            display: flex;
            flex-direction: column;
            height: 100vh;
            margin: 0;
        }

        header {
            background-color: #f0f0f0;
            padding: 10px;
            text-align: center;
        }

        .message-list {
            flex-grow: 1;
            overflow-y: auto;
        }

        .messages {
            display: flex;
            flex-direction: column;
            padding: 10px;
        }

        .unread-messages,
        .read-messages {
            display: flex;
            flex-direction: column;
        }

        .notif {
            border: 1px solid #ccc;
            margin: 5px;
            padding: 10px;
            cursor: pointer;
            transition: background-color 0.3s;
            position: relative;
        }

        .notif:hover {
            background-color: #DDF1D3;
        }
       

        .read {
            background-color: #f0f0f0;
        }

        .notif .date {
            position: absolute;
            top: 5px;
            right: 5px;
            color: #666;
        }

        .message-popup {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            align-items: center;
            justify-content: center;
        }

        .popup-content {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            position: relative;
        }

        .close-btn {
            cursor: pointer;
            position: absolute;
            top: 10px;
            right: 10px;
        }
    </style>
</head>

<body>

<div id="modal3" class="modal">
  <div class="modal-content">
 <span class="close-btn" onclick="closeModal('modal3')">&times;</span>

    <div class="message-list">
        <!-- Unread Messages -->
        <div class="unread-messages">
            <h5>Notifications</h5>
            <div class="messages" id="unreadContainer">
                <!-- Unread messages will be added here -->


                                            <?php

                                            include("../config/conn.php");
                                            // Assuming $currentUserStudID is the current user's student ID
                                            $currentUserStudID = $_SESSION['id']; // Replace with your actual code to get the user's student ID

                                            $req = $conn_PDO->prepare("SELECT * FROM reqchange");
                                            $req->execute();

                                            if ($req->rowCount() > 0) {
                                                while ($fetch_req = $req->fetch(PDO::FETCH_ASSOC)) {
                                                    // Check if StudNum in the database matches the current user's student ID
                                                    if ($fetch_req['StudNum'] == $currentUserStudID) {
                                            ?>
                                                        <div class="notif" data-index="<?= $fetch_req['date']; ?>" onclick="openMessage(this)">
                                                            <div class="sender-info">
                                                                <span class="sender-name"><b>From:ICST</b></span>
                                                                <span class="date"><?= $fetch_req['date']; ?></span>
                                                            </div>
                                                            <div class="message-content">
                                                                <p>We received your request to change data. Please wait until we verify your information. Thank you!</p>
                                                            </div>
                                                        </div>
                                            <?php
                                                    }
                                                }
                                            }
                                            ?>


            </div>
            <hr><strong><hr></strong>
        </div>

        <!-- Read Messages -->
        <div class="read-messages">
            <h5></h5>
            <div class="messages" id="readContainer">
                <!-- Read messages will be added here -->
            </div>
        </div>
    </div>

    <div class="message-popup" id="messagePopup">
        <div class="popup-content">
            <span class="close-btn" onclick="closeMessage()">×</span>
            <div class="sender-info">
                <span class="sender-name">John Doe</span>
                <span class="message-date">2023-01-01</span>
            </div>
            <!-- Add data-index attribute to uniquely identify each message -->
            <div class="message-content">
                This is the detailed content of the message.
            </div>
        </div>
    </div>

    <script type="text/javascript">
        <script>
            // Example list of student IDs (replace this with your actual data)
            var studentIds = document.getElementsByClassName("sender-name");

            // Check for each student ID if data has been sent
            for (var i = 0; i < studentIds.length; i++) {
              var studId = studentIds[i];
              var hasSentData = hasSentDataForStudent(studId);

              // Display a message in the notification modal for each student
              var notificationMessage = "Data for student ID " + studId + (hasSentData ? " has been sent!" : " has not been sent.");
              $("#notificationMessages").append("<p>" + notificationMessage + "</p>");
            }

            // Show the notification modal
            $("#notificationModal").modal('show');

            // Replace this function with your actual logic to check if data has been sent for a student
            function hasSentDataForStudent(studentId) {
              // Your logic to check if data has been sent for the student goes here
              // Return true if data has been sent, false otherwise
              return (Math.random() < 0.5); // Replace with your actual check
            }
</script>
    </script>

</body>

</html>

                        </div>
                    </div>