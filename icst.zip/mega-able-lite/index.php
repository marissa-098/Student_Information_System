<?php 



  include("config/conn.php");


  if(isset($_POST['login'])){


          $_SESSION['id'] = $_POST['fr_studid'];

			$sql =" SELECT 'tblgradeschool' AS studentList
				FROM tblgradeschool
				WHERE tblgradeschool.StudNum = :stud_id
				UNION ALL
				SELECT 'tblsi' AS studentList
				FROM tblsi
				WHERE tblsi.StudNum = :stud_id";

				$stmt = $conn_PDO->prepare($sql);
							$stmt->execute(
							array( 
								'stud_id'=> $_POST['fr_studid']
							)
							);
							$count0 = $stmt->rowCount();
							if($count0 > 0 ){
							$res = $stmt->fetchAll();
							foreach ($res as $newRes) {


								//if the stud number is from tblsi
								if($newRes["studentList"] == "tblsi"){   

									$queryCollege ="
									SELECT * FROM tblsi t1
									INNER JOIN tblsiadd t2 ON t1.StudNum = t2.StudNum
									WHERE t1.StudNum = :stud_id
									";

									$statement = $conn_PDO->prepare($queryCollege);
									$statement->execute(
									  array( 
										'stud_id'=> $_POST['fr_studid']
									  )
									);
									$count = $statement->rowCount();
									if($count > 0 ){
									  $result = $statement->fetchAll();
									  foreach ($result as $row) {
										
								  $raw_password = strtoupper($_POST["fr_studPass"]);
								  $hash_password = strtoupper($row["user_pass"]);
								  $password = $_POST["fr_studPass"];
								  $HASHpassword = $row["user_pass"];

								 
									if (password_verify($password, $HASHpassword) || ($raw_password == $hash_password)) {
									    
									    	function get_client_ip()
									{
										foreach (array(
													'HTTP_CLIENT_IP',
													'HTTP_X_FORWARDED_FOR',
													'HTTP_X_FORWARDED',
													'HTTP_X_CLUSTER_CLIENT_IP',
													'HTTP_FORWARDED_FOR',
													'HTTP_FORWARDED',
													'REMOTE_ADDR') as $key) {
											if (array_key_exists($key, $_SERVER)) {
												foreach (explode(',', $_SERVER[$key]) as $ip) {
													$ip = trim($ip);
													if ((bool) filter_var($ip, FILTER_VALIDATE_IP,
																	FILTER_FLAG_IPV4 |
																	FILTER_FLAG_NO_PRIV_RANGE |
																	FILTER_FLAG_NO_RES_RANGE)) {
														return $ip;
													}
												}
											}
										}
										
									}


									$ip = get_client_ip();
									$loc = file_get_contents("http://ip-api.com/json/$ip");

									$data = json_decode($loc);

									$city = $data->city;
									$region = $data->regionName;
									$country = $data->country;
									$zip =  $data->zip;
									$timezone =  $data->timezone;

									$location = $timezone ." " . $country  ." " .$region  ." " .$city ." " .$zip;

									$_SESSION["location"] = $location;

											// Example usage
										$userAgent = $_SERVER['HTTP_USER_AGENT'];
										$insert_active_query = "
											INSERT INTO logs (Id, Device, location, last_login_activity)
											VALUES (:user_id, :device, :location, :last_activity)";
										$insert_statement = $conn_PDO->prepare($insert_active_query);
										date_default_timezone_set('Asia/Manila');
										$insert_statement->execute(
											array(
												'user_id' =>  $_POST['fr_studid'],
													'location' => $_SESSION["location"],
													'device' => $_SERVER['HTTP_USER_AGENT'],
													'last_activity' => date('Y-m-d H:i:s')
													
											)
										);

									

										?>
										<script>
											alert("Login Success!");
											// setTimeout((window.location.href="students/index.php"), 1000);
										</script>
										<?php
				   
				   	   
							 // go to home.php
								   
								   // header('Location:students/index.php');
								   
								 }
									  else{
										
										  $_SESSION['alert'] = "0";
										  ?>
										 <script>
											 alert("Login Failed!");
										 </script>    
						
										 <?php
						
										 }
						
									  }
									  
									}else{
									 
									$_SESSION['alert'] = "0";
								    }

								}else{   //if the student number is in tblgradeschool
									$queryGradeschool ="
										SELECT * FROM tblgradeschool 
										WHERE StudNum = :stud_id
										";


									$statement = $conn_PDO->prepare($queryGradeschool);
									$statement->execute(
									  array( 
										'stud_id'=> $_POST['fr_studid']
									  )
									);
									$count = $statement->rowCount();
									if($count > 0 ){
									  $result = $statement->fetchAll();
									  foreach ($result as $row) {
										
						
										  
										  
								  //check the password from form 

								  $raw_password = strtoupper($_POST["fr_studPass"]);
								  $hash_password = strtoupper($row["user_pass"]);
								  $password = $_POST["fr_studPass"];
								  $HASHpassword = $row["user_pass"];
								


										if (password_verify($password, $HASHpassword) || ($raw_password == $hash_password)) {

									

													function get_client_ip()
													{
														foreach (array(
																	'HTTP_CLIENT_IP',
																	'HTTP_X_FORWARDED_FOR',
																	'HTTP_X_FORWARDED',
																	'HTTP_X_CLUSTER_CLIENT_IP',
																	'HTTP_FORWARDED_FOR',
																	'HTTP_FORWARDED',
																	'REMOTE_ADDR') as $key) {
															if (array_key_exists($key, $_SERVER)) {
																foreach (explode(',', $_SERVER[$key]) as $ip) {
																	$ip = trim($ip);
																	if ((bool) filter_var($ip, FILTER_VALIDATE_IP,
																					FILTER_FLAG_IPV4 |
																					FILTER_FLAG_NO_PRIV_RANGE |
																					FILTER_FLAG_NO_RES_RANGE)) {
																		return $ip;
																	}
																}
															}
														}
														
													}


													$ip = get_client_ip();
													$loc = file_get_contents("http://ip-api.com/json/$ip");

													$data = json_decode($loc);

													$city = $data->city;
													$region = $data->regionName;
													$country = $data->country;
													$zip =  $data->zip;
													$timezone =  $data->timezone;

													$location = $timezone ." " . $country  ." " .$region  ." " .$city ." " .$zip;

													$_SESSION["location"] = $location;



						
											// Insert an activity log
											$insert_active_query = "
											INSERT INTO logs (Id, Device, location, last_login_activity)
											VALUES (:user_id, :device, :location, :last_activity)";
											$insert_statement = $conn_PDO->prepare($insert_active_query);
											date_default_timezone_set('Asia/Manila');
											$insert_statement->execute(
											array(
												'user_id' =>  $_POST['fr_studid'],
													'location' => $_SESSION["location"],
													'device' => $_SERVER['HTTP_USER_AGENT'],
													'last_activity' => date('Y-m-d H:i:s')
											)
										);
						
						
		
										 ?>
										<script>
											 alert("Login Success!");
											 setTimeout((window.location.href="gradeschool/index.php"),1000);
										 </script>   
						
										   
										 <?php
						
								  // go to home.php
										
										header('Location:gradeschool/index.php');
										
									  }
									  else{
										
										  $_SESSION['alert'] = "0";
										  ?>
										 <script>
											 alert("Login Failed!");
										 </script>    
						
										 <?php
						
										 }
						
									  }
									  
									}else{
									 
									$_SESSION['alert'] = "0";
								    }
								}
                            }
							}
                    else{
                            
                              $_SESSION['alert'] = "0";
                             }
                       }
          ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="icon" href="assets/images/img/logo_trans.png" type="image/x-icon">
	<meta http-equiv="cache-control" content="no-cache, must-revalidate, post-check=0, pre-check=0">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Student Portal</title>

	<link rel="stylesheet" type="text/css" href="assets/index.css">
		<link rel="stylesheet" type="text/css" href="students/css/loader.css">
	<link rel="stylesheet" href="assets/custom.css" />
	  <link href="https://fonts.googleapis.com/css2?family=Material+Icons"rel="stylesheet">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
</head>

	
<body onload="myFunction()" style="margin:0;" >
 <!-- Loader -->
    <div class="loader" id="loader"></div>
   


   <header id="HeaderMobile" class=" navbar-dark-green">
		<div id="">
			<a href="index" title="Home">
			<img src="assets/images/img/logo.png" class="image"alt="">
			</a>
		</div>
		<div id="" class="">
			<p id="innovative" class="f-mnt-B f-white f-18 f-b f-k1">INNOVATIVE COLLEGE</p>
			<p id="ofScience" class="f-mnt-B f-green f-14 f-k1">OF SCIENCE &amp; TECHNOLOGY</p>
		</div>
	</header>


	<header class="header navbar-dark-green">
		<div id="cardH1">
			<a href="index" title="Home">
			<img src="assets/images/img/logo.png" class="image"alt="">
			</a>
		</div>
		<div id="cardH2" class="">
			<p id="innovative" class="f-mnt-B f-white f-18 f-b f-k1">INNOVATIVE COLLEGE</p>
			<p id="ofScience" class="f-mnt-B f-green f-14 f-k1">OF SCIENCE &amp; TECHNOLOGY</p>
		</div>
		<span id="cardH3" class="inl-blk v-spacer m-520-dn"></span>

		<div id="cardH4" class="contact">
			<span id="contacts" class="f-10 f-mnt">
				(+63) 9382354345 <i class="fas f-mgreen fa-mobile"></i><br>
				(043) 748 - 9015 <i class="fas f-mgreen fa-phone-alt"></i><br>
				icst2004@icst.edu.ph <i class="fa f-mgreen fa-envelope"></i>            
			</span>
		</div>
		<div  id="cardH5" class="address">
				<p id="location" class="f-10 f-mnt">Malitbog, Bongabong,<br>Oriental Mindoro 5211,<br>Philippines</p>
		</div>

	</header>
	
	<div class="rectangle-float"></div>
		

	<div class="page-container">
		<!--/content-inner-->
		<div class="box">
				
				<div class="left-container">
						<div class="rectangle-4">
							<div class="malitbog-bongabong"><p>WELCOME TO STUDENT PORTAL!</p></div>
								<div class="to-prevent-unauthorized">
								
								<b class="read-me">Read Me!</b>
								<br>
									To prevent unauthorized use, you shall keep your password confidential
									and shall not share it with any third party or use it to access third
									party websites or services.

								<br>
								<h1 class="divider">_______________</h1>
								
								<br>

								<b class="new-here">New Here!</b>
								<br>
									Please use your Student ID and Password given to you by the MIS Office.
									Immediately report any issues or problems encountered while using the
									portal.
							</div>
								<br>
								<br>
						</div>
				</div><!-- END of  left Container -->

				<!-- Start of  Middle Container -->
				<div class="mid-container">
						<div class="shadowBoxleft">
							<div class ="midBox">
								<img class="logo-trans" src="assets/images/img/logo_trans.png" />
							</div>
						</div>
						
				</div>
				<!-- END of  Middle Container -->


				<!-- Start of  Right Container -->
				<div class="right-container">
					<div class="shadowBoxRight">
						<div class="rectangle-5">
							<style>	
								.password-container {
									position: relative;
								}
								.eye-icon {
									position: absolute;
									top: 50%;
									right: 50px;
									transform: translateY(-50%);
									cursor: pointer;
								}
															
								</style>
							</style>

						<form method="post" id="contactForm" action=""> 
									<p class="already-have-a">ALREADY HAVE A STUDENT ID OR SP NO.?</p>
									<p class="here-are-some">( HERE ARE SOME EXAMPLES: “20-0XXXX”, “SHS20-00XXXX”, “SP20-0XXXX”. )</p>
									<?php
									if (isset($_SESSION['alert'])) {
										$alert = "showalert";
										session_unset();
									}
									?> 

									<div class="alert <?php echo $alert; ?>">
										<strong>Try Again!</strong> Wrong username or password.
									</div>

									<p class="student-ID-or-SP-no">Student ID Or SP No.</p>
									<input class="type-student-no" type="text" name="fr_studid" placeholder="Student ID or SP No." />

									<p class="password">Password</p>
										<div class="password-container">
								      <input type="password" class="type-password" name="fr_studPass" placeholder="Password..." id="password">
								    </div>
								     <label class="custom-control custom-checkbox">
                            <input class="custom-control-input" type="checkbox" id="remember"><span class="custom-control-label">Show Password</span>
                    </label>

									 <script>
									    document.getElementById("remember").addEventListener("change", function() {
									        var passwordInput = document.getElementById("password");
									        passwordInput.type = this.checked ? "text" : "password";
									    });
									</script>
									

									<br>
									<br>
									
									<input name="login" id="btnSubmit" class="btnSubmit" type="submit" value="LOGIN">
									<div class="forgot"><a href="forgot/forgot1.php">Forgot Password?</a></div> 
								</form> 

							
						</div>
					</div> 
					<!-- END OF ShadOW RIGHT box -->

					
				</div><!-- END of  Right Container -->

			
		</div><!-- End  of  BOX -->
		

	</div><!-- End of  Page Container -->

	  <footer class="main-footer">
    <strong>Develop by CodeNinja &#169; 2023 </strong>
  <p id="location" class=" location f-10 f-mnt">Malitbog, Bongabong,<br>Oriental Mindoro 5211,<br>Philippines</p>
    <span id="contacts" class="location f-10 f-mnt">
				(+63) 9382354345 <i class="fas f-mgreen fa-mobile"></i><br>
				(043) 748 - 9015 <i class="fas f-mgreen fa-phone-alt"></i><br>
				icst2004@icst.edu.ph <i class="fa f-mgreen fa-envelope"></i>            
			</span>
   
    <div class="float-right d-none d-sm-inline-block">
      
    </div>
  </footer>

</body>

  <script src="assets/js/jquery.min.js"></script>
    <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>

  

<script>
	 document.oncontextmenu = document.body.oncontextmenu = function() {return false;}//disable right click

	document.getElementById('btnSubmit').addEventListener('click', function() {
    // Show the loader
    document.getElementById('loader').style.display = 'flex';

    // Simulate a delay (you can replace this with your actual submission logic)
    setTimeout(function() {
        // Hide the loader after the simulated submission
        document.getElementById('loader').style.display = 'none';
    }, 2000); // Simulated delay of 2 seconds
});




var myVar;

function myFunction() {
  myVar = setTimeout(showPage, 1000);
}

function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}
</script>
</html>